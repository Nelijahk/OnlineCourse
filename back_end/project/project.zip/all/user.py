from flask import request, Blueprint
from flask_httpauth import HTTPBasicAuth

from all.models import *
from werkzeug.security import check_password_hash

user_query = Blueprint('user_query', __name__)
auth = HTTPBasicAuth()

@auth.verify_password
def verify_password(user_name, password):
    user = User.query.filter(User.user_name == user_name).first()
    if user and check_password_hash(user.password, password):
        return user_name
    return None

@user_query.route('/user', methods = ['POST'])
def add_user():
    params = request.json
    user = User(**params)
    exists = session.query(User.id_user).filter_by(user_name=params['user_name']).first()
    if exists:
        return 'User with such username already exists.', 401
    if not (params['status'] == 'Teacher' or params['status']  == 'Student'):
        return 'Incorrect status', 402
    session.add(user)
    session.commit()
    return 'Successful operation', 200

@user_query.route('/user/<int:id_user>', methods = ['PUT'])
@auth.login_required
def update_user(id_user):
    user = User.query.filter(User.id_user == id_user).first()
    if user.user_name != auth.username():
        return 'Access is denied', 405
    if not user:
        return "User with such ID does not exists", 401
    params = request.json
    if 'password' in params:
        params['password'] = generate_password_hash(params['password'])
    for key, value in params.items():
        setattr(user, key, value)
    if 'status' in params:
        return 'You can not change your status', 402
    session.commit()
    session.close()
    return 'Successful operation', 200

@user_query.route('/user/<int:id_user>', methods=['DELETE'])
# @auth.login_required()
def delete_user(id_user):
    user = User.query.filter(User.id_user == id_user).first()
    if not user:
        return "User with such ID does not exists", 401
    session.delete(user)
    session.commit()
    return 'Successful operation', 200
